from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponseForbidden, HttpResponseNotFound
from .models import Data, Title, Course
from .forms import ExcelUploadForm, TitleForm, CourseForm
import pandas as pd
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import logging

logger = logging.getLogger(__name__)

def home(request):
    try:
        unique_titles = Data.objects.values('title').distinct()
        course_titles = Title.objects.all()
        form = ExcelUploadForm()

        if request.method == 'POST':
            try:
                logger.info(f"{request.user.username} - POST - Handling Excel file upload: {request.body}")
                form = ExcelUploadForm(request.POST, request.FILES)
                
                if form.is_valid():
                    excel_file = request.FILES['excel_file']
                    try:
                        df = pd.read_excel(excel_file)
                        for index, row in df.iterrows():
                            title = row['Title']
                            topic = row['Topic']
                            link = row['Link']
                            Data.objects.create(title=title, topic=topic, link=link)
                        return redirect('home')
                    except pd.errors.ParserError as parser_error:
                        form.add_error('excel_file', f'Invalid Excel file. {parser_error}')
            except Exception as post_error:
                logger.error(f"{request.user.username} - Exception during POST request - Home view: {post_error}")
                return HttpResponseNotFound(f"Unable to process the request.")

        logger.debug(f"{request.user.username} - Debug message in home view")
        logger.info(f"{request.user.username} - Info message in home view")

        return render(request, 'home.html', {'titles': unique_titles, 'course_titles': course_titles, 'form': form})
    except Exception as e:
        logger.exception(f"{request.user.username} - Exception in home view: {str(e)}")
        return redirect('home')  

def title_details(request, title):
    try:
        details = Data.objects.filter(title=title)
        paginator = Paginator(details, 10)
        page = request.GET.get('page')

        try:
            details = paginator.page(page)
        except PageNotAnInteger:
            details = paginator.page(1)
        except EmptyPage:
            details = paginator.page(paginator.num_pages)

        breadcrumb = title.split("/")
        
        return render(request, 'title_details.html', {'details': details, 'breadcrumb': breadcrumb})
    except Exception as e:
        logger.exception(f"{request.user.username} - Exception in title_details view: {str(e)}")
        return redirect('home') 

def add_title(request):
    try:
        if request.method == 'POST':
            logger.info(f"{request.user.username} - POST - Handling TitleForm: {request.body}")
            form = TitleForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('home')
        else:
            form = TitleForm()

        return render(request, 'add_title.html', {'form': form})
    except Exception as e:
        logger.exception(f"{request.user.username} - Exception in add_title view: {str(e)}")
        return redirect('home') 

def add_course(request):
    try:
        if request.method == 'POST':
            logger.info(f"{request.user.username} - POST - Handling CourseForm: {request.body}")
            form = CourseForm(request.POST)
            if form.is_valid():
                title_id = request.POST.get('title')
                title = Title.objects.get(id=title_id)
                form.instance.title = title
                form.save()
                return redirect('home')
        else:
            form = CourseForm()

        titles = Title.objects.all()
        return render(request, 'add_course.html', {'form': form, 'titles': titles})
    except Exception as e:
        logger.exception(f"{request.user.username} - Exception in add_course view: {str(e)}")
        return redirect('home')  

def course_titles(request, title_id):
    try:
        title = get_object_or_404(Title, id=title_id)
        courses = Course.objects.filter(title=title)

        paginator = Paginator(courses, 10)
        page = request.GET.get('page')

        try:
            courses = paginator.page(page)
        except PageNotAnInteger:
            courses = paginator.page(1)
        except EmptyPage:
            courses = paginator.page(paginator.num_pages)

        return render(request, 'course_titles.html', {'title': title, 'courses': courses})
    except Exception as e:
        logger.exception(f"{request.user.username} - Exception in course_titles view: {str(e)}")
        return redirect('home')  

def delete_course(request, course_id):
    try:
        course = get_object_or_404(Course, id=course_id)

        Data.objects.filter(title=course.title, topic=course.topic, link=course.link).delete()

        course.delete()

        return redirect('course_titles', title_id=course.title.id)
    except Exception as e:
        logger.exception(f"{request.user.username} - Exception in delete_course view: {str(e)}")
        return redirect('home')  

def user_has_permission_to_delete(user, course):
    return user == course.title.creator
