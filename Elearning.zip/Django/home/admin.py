

# Register your models here.
# home/admin.py

from django.contrib import admin
from .models import Data,Course,Title
admin.site.register(Data)
admin.site.register(Course)
admin.site.register(Title)

