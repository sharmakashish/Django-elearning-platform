# home/models.py

from django.db import models
from django.urls import reverse

class Data(models.Model):
    title = models.CharField(max_length=255)
    topic = models.CharField(max_length=255)
    link = models.URLField()

class Title(models.Model):
    title = models.CharField(max_length=100)

    def __str__(self):
        return self.title

class Course(models.Model):
    title = models.ForeignKey(Title, on_delete=models.CASCADE)
    topic = models.CharField(max_length=255)
    link = models.URLField()

    def __str__(self):
        return self.topic

    def delete_course(self):
        # Implement your logic for deleting a course
        # For example, you can confirm deletion with a user prompt
        confirmation = input(f"Are you sure you want to delete '{self.topic}'? (yes/no): ")
        
        if confirmation.lower() == 'yes':
            # Perform additional checks or actions if needed
            self.delete()
            return f"Course '{self.topic}' deleted successfully."
        else:
            return f"Deletion of '{self.topic}' canceled."

    def get_absolute_url(self):
        return reverse('course_titles', args=[str(self.title.id)])
