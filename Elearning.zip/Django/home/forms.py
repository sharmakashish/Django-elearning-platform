# Home/forms.py

from django import forms
from .models import  Title, Course


class ExcelUploadForm(forms.Form):
    excel_file = forms.FileField()
class TitleForm(forms.ModelForm):
    class Meta:
        model = Title
        fields = ['title']

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['topic', 'link']




