# Home/urls.py

from django.urls import path
from .views import home, add_title, title_details, add_course,course_titles,delete_course


urlpatterns = [
    path('', home, name='home'),
    path('add_title/', add_title, name='add_title'),
    path('title_details/<str:title>/', title_details, name='title_details'),
    path('add_course/', add_course, name='add_course'), 
    path('course_titles/<int:title_id>/', course_titles, name='course_titles'),
    path('delete_course/<int:course_id>/', delete_course, name='delete_course'),
    
] 